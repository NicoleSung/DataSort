public class pollution {
    private String date;
    private String state;
    private String city;
    private int year;
    private int month;
    private int day;
    private double O3Mean;
    private double MaxValue;
    private int AQI;

    // default constructor
    public pollution(){
        date = "";
        state = "";
        city = "";
        year = 0;
        month = 0;
        day = 0;
        O3Mean = 0;
        MaxValue = 0;
        AQI = 0;
    }

    // parametrized constructor
    public pollution(String date, int year, int month, int day, String state, String city, double O3Mean, double MaxValue, int AQI){
        this.date = date;
        this.year = year;
        this.month = month;
        this.day = day;
        this.state = state;
        this.city = city;
        this.O3Mean = O3Mean;
        this.MaxValue = MaxValue;
        this.AQI = AQI;
    }

    // copy constructor
    public pollution(pollution p){
        date = p.date;
        year = p.year;
        month = p.month;
        day = p.day;
        state = p.state;
        city = p.city;
        O3Mean = p.O3Mean;
        MaxValue = p.MaxValue;
        AQI = p.AQI;
    }

    // getters and setters
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public double getO3Mean() {
        return O3Mean;
    }

    public void setO3Mean(double o3Mean) {
        O3Mean = o3Mean;
    }

    public double getMaxValue() {
        return MaxValue;
    }

    public void setMaxValue(double maxValue) {
        MaxValue = maxValue;
    }

    public int getAQI() {
        return AQI;
    }

    public void setAQI(int AQI) {
        this.AQI = AQI;
    }

    @Override
    public String toString() {
        return "pollution{" +
                "date='" + date + '\'' +
                ", state='" + state + '\'' +
                ", city='" + city + '\'' +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", O3Mean=" + O3Mean +
                ", MaxValue=" + MaxValue +
                ", AQI=" + AQI +
                '}';
    }



}
