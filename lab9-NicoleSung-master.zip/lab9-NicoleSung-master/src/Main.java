import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.StreamSupport;

public class Main {

    //Method declarations
    public static int transpositionSort(ArrayList<pollution> a, int size){
        boolean odd = true; // start with odd elements
        boolean isSorted = false; // arraylist is not sorted
        count swap2 = new count(); // count swaps
        swap2.clear();

        sortByAQI comparator = new sortByAQI(); // compare objects
        // while arraylist is not sorted
        while(!isSorted) {
            isSorted = true; // optimized way to stop the while loop
            if (odd){ // odd elements
                for (int i = 1; i<size-1;i+=2){
                    isSorted = isSorted(a, isSorted, comparator, i, swap2); // swap method
                }
                odd = false; // next round becomes even
            }
            else{ // even elements
                for (int i = 0; i<size-1;i+=2){
                    isSorted = isSorted(a, isSorted, comparator, i, swap2); // swap method
                }
                odd = true; // next round becomes odd
            }
        }
        return swap2.getNum();
    }

    private static boolean isSorted(ArrayList<pollution> a, boolean isSorted, sortByAQI comparator, int i, count swap) {
        pollution temp; // temporary storing variable

        // if the first element is greater than the next element -> swap
        if (comparator.compare(a.get(i),a.get(i+1))>0){
            temp = a.get(i);
            a.set(i, a.get(i+1));
            a.set(i+1, temp);
            isSorted = false; // the arraylist is not sorted because it is swapped
            swap.increase();  // the number of swaps increase by 1
        }
        return isSorted;
    }

    public static void mergeSort(ArrayList<pollution> a, ArrayList<pollution> tmp, int left, int right, count swap){
        // divide array into individual element level
        if (left<right){
            int middle = (left+right)/2; // middle index
            mergeSort(a,tmp,left,middle, swap); // left part of the array
            mergeSort(a,tmp,middle+1,right, swap); // right part of the array
            mergeSortedLists(a,tmp,left,middle,right, swap); // merge 2 parts together
        }
    }

    public static void mergeSortedLists(ArrayList<pollution> a, ArrayList<pollution> tmp, int left, int middle, int right, count swap){
        int indexL = left;      // first index of the left part of the array
        int indexR = middle +1; // first index of the right part of the array
        sortByAQI comparator = new sortByAQI(); // compare object

        // compare left and right elements
        while (indexL<=middle && indexR <= right){
            if (comparator.compare(a.get(indexL),a.get(indexR))<=0){ // right index element is larger
                tmp.add(a.get(indexL)); // add left index element
                indexL++; // move to next left index
            }
            else{ // left index element is larger
                tmp.add(a.get(indexR)); // add right index element
                indexR++; // move to next right index
                swap.increase(); // increase swap
            }
        }
        // if there are leftover left index elements in the array
        while (indexL<=middle){
            tmp.add(a.get(indexL));
            indexL++;
        }

        // if there are leftover right index elements in the array
        while (indexR<=right){
            tmp.add(a.get(indexR));
            indexR++;
        }

        // add elements in tmp to a starting at the first index (left)
        for (pollution pollution : tmp) {
            a.set(left, pollution);
            left++;
        }

        tmp.removeAll(tmp); // clear all elements in tmp
    }


    public static void main(String [] args){
        //.....
        //....
        ArrayList<pollution> list=new ArrayList<pollution>();   // list to be sorted
        ArrayList<pollution> tmp=new ArrayList<pollution>();   // temporary workspace
        Scanner scnr = new Scanner(System.in);
        //fill list

        // open pollution file and handle exception
        FileInputStream file = null;
        try {
            file = new FileInputStream("src/pollution_2000_2021.csv");
        }
        catch (FileNotFoundException e) {
            System.out.println("Could not open input file: " + e);
            System.exit(1);
        }

        // use Scanner to read the opened file
        Scanner fileReader = new Scanner(file);

        // initiate arraylist and variables
        String temp;
        String [] tempArr;
        pollution tempObj;
        String date,state,city;
        int year;
        int month,day;
        double mean;
        double max;
        int AQI;

        // ask the user to determine the sorting size
        System.out.println("What is the size?");
        int size = 0;
        try {
            size = scnr.nextInt();
        }
        catch (NumberFormatException e) {
            System.out.println("Could not understand the size input: " + e);
            System.exit(1);
        }
        int inputData = 0;

        // read lines from the file, limited by the sorting size
        fileReader.nextLine();
        while (fileReader.hasNextLine() && inputData<size){

            // handle commas in quotes issue and split string into array
            temp = fileReader.nextLine();
            tempArr = temp.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);

            // add them into the arraylist
            date = tempArr[0];
            year =Integer.parseInt(tempArr[1]);
            month = Integer.parseInt(tempArr[2]);
            day = Integer.parseInt(tempArr[3]);
            state = tempArr[5];
            city = tempArr[7];
            mean = Double.parseDouble(tempArr[8]);
            max = Double.parseDouble(tempArr[9]);
            AQI = Integer.parseInt(tempArr[11]);

            // create a new object
            tempObj = new pollution(date,year,month,day,state,city,mean,max,AQI);

            //  add it into the arraylist
            list.add(tempObj);

            // change in condition
            inputData++;
        }

        // close the file reader
        fileReader.close();

        //Create a copy from list for Transition sort
        ArrayList <pollution> list2=new ArrayList<pollution>();
        for (pollution pollution : list) list2.add(pollution);

        // merge sort

        // merge sort calculate the sorting time
        long startTime;
        long finishTime;
        count swap = new count(); // count swaps

        startTime = System.nanoTime(); // begin timing
        // sort list using mergesort
        mergeSort(list, tmp, 0, list.size()-1, swap);
        finishTime = System.nanoTime(); // stop timing

        // convert into second
        long executionTime =  finishTime - startTime;
        double executionTimeSecond = (double) executionTime / 1000000000;

        // create a new file to store the swaps for merge sort
        FileOutputStream newFile =null;
        try{
            newFile = new FileOutputStream("src/mergeSortSwap.txt", true);
        }catch(FileNotFoundException e){
            System.out.println("File not able to create");
            System.exit(1);
        }

        // open file in a PrintWriter
        PrintWriter fileWriter = new PrintWriter(newFile);
        // write size, swaps, and according sorting time in the file
        fileWriter.println(size + ","+ swap.getNum() + ","+ executionTimeSecond);

        // close fileWriter
        fileWriter.close();

        // transposition sort

        // transposition sort calculate the sorting time
        long startTime2;
        long finishTime2;

        startTime2 = System.nanoTime(); // begin timing
        //sort list2 using Bubble sort
        int swap2 = transpositionSort(list2, list2.size());
        finishTime2 = System.nanoTime(); // stop timing

        // convert into second
        long executionTime2 =  finishTime2 - startTime2;
        double executionTimeSecond2 = (double) executionTime2 / 1000000000;

        // create a new file to store the swaps for transposition sort
        FileOutputStream newFile2 =null;
        try{
            newFile2 = new FileOutputStream("src/transpositionSort.txt", true);
        }catch(FileNotFoundException e){
            System.out.println("File not able to create");
            System.exit(1);
        }

        // open file in a PrintWriter
        PrintWriter fileWriter2 = new PrintWriter(newFile2);
        // write size, swaps, and according sorting time in the file
        fileWriter2.println(size + ","+ swap2 + ","+ executionTimeSecond2);

        // close fileWriter
        fileWriter2.close();

        // print function that can be used as testing
        // for (pollution pollution : list) System.out.println(pollution);
    }
}


/*
Merge Sort
Based on the merge sort, it can be simplified as
while the arraylist is not divide into individual blocks (N/2) -- O(log N)
    mergeSortedLists  -- O(N)

O(N*log N)
Because we are dividing the array into 2 part, the complexity is O(log N). After we divided them, we merge two parts
together. mergeSortedLists Method is O(N) because it needs to loop through every element in the first and second parts
of the array (worst case scenario) and sort them into the right order. In addition, we need to loop through element
in tmp and add them in to the main arraylist (this can be ignored in the calculation of complexity). So the complexity
of merge sort is O(N*log N).

In my graph, the R^2 is 0.986 shows it's likely to be O(N*log N). When I analyze the number of swaps and time, there is
no significant increase when N is increasing. Which means it is somehow related to log N. And the steady increase along
with the increasing N indicates it can be N*log N. The graph itself is very convincing when comparing with the given
N*log N graph.

Transposition Sort
Based on the Transposition sort, it can be simplified as
while (unknown N times){      -- O(N)
    if even, for (size N)     -- O(N) bubble sort
        arraylist swap        -- O(1)
    else odd, for (size N)    -- O(N) bubble sort
        arraylist swap        -- O(1)
}
O(N^2)
The while loop is O(N) because it is unknown but directly correlated with the data size N. Then, we do the bubble sort
based on even or odd. Bubble sort is O(N) because we need to loop through all the elements in the data, compare with
the adjacent elements, and swap. If we are doing parallelism, since we have N processor and each compare 2 elements,
this step will be O(1). Swapping elements is O(1) because it does not involve shifting. So the complexity of
transposition sort is O(N^2).

In my graph, it can be justified as O(N^2) despite having some off-points. The R^2 is 0.968. I reused my ratio
relationship for O(N^2) when data is getting larger: T(kN) = k^2*T(N). Since T(2N) = 4T(N), if I choose N = 10000, 4
T(10000) = 6.74833446 and T(20000) = 6.66475124. They are very close thus, it supports the O(N^2) complexity. When
N = 15000, the number of swaps almost doubled comparing with N = 10000. Since the data I used is not sorted and the
pollution measurement is very different across my dataset, so there might be a drastic increased in swaps.
 */