interface Comparator<pollution>{
    int compare(pollution obj1, pollution obj2);
}
