import java.util.Comparator;

public class sortByAQI implements Comparator<pollution> {
    @Override
    public int compare(pollution p1, pollution p2) {
        int AQICompare = Integer.compare(p1.getAQI(), p2.getAQI());
        int dateCompare = String.CASE_INSENSITIVE_ORDER.compare(p1.getDate(),p2.getDate());
        if (AQICompare == 0) {
            return dateCompare;
        } else {
            return AQICompare;
        }
    }
}
