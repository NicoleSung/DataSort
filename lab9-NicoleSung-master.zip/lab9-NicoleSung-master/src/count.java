public class count {
    static int num = 0;
    void increase(){
        num++;
    }
    int getNum(){
        return num;
    }
    void clear(){
        num = 0;
    }
}
